<?php
    $GLOBALS['config'] = [

        'landing' => [
            'controller' => 'pages',
            'action' => 'home'
        ],

        'base_url' => 'http://localhost/tovuti/',
        'mongodb' => "mongodb://localhost:27017"
    ];
?>
