<form action="" method="post">
    <input class="form " type="text" placeholder="Username" name="user[name]" required autofocus><br>
    <input class="form" type="password" placeholder="Password" name="user[password]" required><br>
    <input class="btn" type="submit" value="Login">
</form>
