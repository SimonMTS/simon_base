<form action="" method="POST" enctype="multipart/form-data">
    <div class="login-form">
        <input class="form"  type="file" name="file" required>
        <br>
        <input class="btn" type="submit" value="Add">
    </div>
</form>
