<p>Wat voor soort documenten kan ik uploaden? - pdf, zip, xlsx, xml, txt, pptx, doc, docx, xls, ppt.</p><br>
<p>Hoeveel documenten kan ik uploaden? - zo veel als je wil.</p><br>
<p>Hoe groot mogen de documenten zijn? - 2mb.</p><br>
