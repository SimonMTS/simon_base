<p>Hallo <?= $name; ?>!</p>
<br>
<p>De regenboog is een middelbare school waar meer dan 400 leerlingen bezig zijn met
een vmbo, havo, of vwo-diploma.<br> De school is gevestigd op de Schoolstraat 1,
Arnhem en is opgericht in 1970.</p>
